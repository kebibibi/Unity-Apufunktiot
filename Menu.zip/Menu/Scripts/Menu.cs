using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Menu : MonoBehaviour
{
    public GameObject menu;
    public GameObject settings;

    public bool isPlaying;

    void Start()
    {
        settings.SetActive(false);
    }

    public void GameOn()
    {
        menu.SetActive(false);
        isPlaying = true;
    }

    public void OpenSettings()
    {
        menu.SetActive(false);
        settings.SetActive(true);
    }

    public void CloseSettings()
    {
        settings.SetActive(false);
        menu.SetActive(true);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
