
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Unity.VisualScripting;
using System.Linq;
using DG.Tweening;

public class AudioButtons : MonoBehaviour
{
    public AudioSource audioSource;

    public List<AudioClip> music = new List<AudioClip>();

    public int randomNumber;
    public int lastNumber;
    int maxAttempts = 10;

    void RandomNumberGen()
    {
        for(int i = 0; randomNumber == lastNumber && i < maxAttempts; i++)
        {
            randomNumber = Random.Range(0, 5);
        }
        lastNumber = randomNumber;
    }

    public void RandomSong()
    {
        audioSource.loop = false;

        RandomNumberGen();
        audioSource.clip = music[randomNumber];
        audioSource.Play();
        if (audioSource.volume == 0)
        {
            RandomSong();
        }
    }

    public void ZoneSong()
    {
        audioSource.loop = true;
    }

    public void LoopSong()
    {
        audioSource.loop = true;

        RandomNumberGen();
        audioSource.clip = music[randomNumber];
        audioSource.Play();
    }

}
